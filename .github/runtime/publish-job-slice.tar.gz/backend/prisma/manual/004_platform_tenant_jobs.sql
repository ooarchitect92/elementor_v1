-- Legacy application to platform-tenancy bridge and website-scoped durable jobs.
-- Apply after infrastructure/postgres/001_platform.sql, 002_runtime.sql, 003_job_resources.sql and 003_core_v1.sql.
-- Run with the reviewed migration role; the application role must remain non-BYPASSRLS.
BEGIN;

DO $$
BEGIN
  IF to_regclass('platform.tenants') IS NULL OR to_regclass('public.users') IS NULL
     OR to_regclass('public.websites') IS NULL THEN
    RAISE EXCEPTION 'Required platform/users/websites tables are missing';
  END IF;
END $$;

INSERT INTO platform.tenants(id, name, status, home_cell)
SELECT
  u.id,
  COALESCE(NULLIF(btrim(u."fullName"), ''), NULLIF(btrim(u.email), ''), 'Personal Workspace'),
  'ACTIVE',
  'local-1'
FROM users u
ON CONFLICT(id) DO NOTHING;

INSERT INTO platform.memberships(tenant_id, user_id, role, status)
SELECT u.id, u.id, 'OWNER', 'ACTIVE'
FROM users u
ON CONFLICT(tenant_id, user_id) DO UPDATE
SET role='OWNER', status='ACTIVE', version=platform.memberships.version + 1;

ALTER TABLE websites
  ADD COLUMN IF NOT EXISTS "tenantId" uuid;

UPDATE websites
SET "tenantId" = "userId"
WHERE "tenantId" IS NULL;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname='websites_tenant_fk'
  ) THEN
    ALTER TABLE websites
      ADD CONSTRAINT websites_tenant_fk
      FOREIGN KEY ("tenantId") REFERENCES platform.tenants(id);
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS websites_tenant_idx
  ON websites("tenantId", "updatedAt" DESC);

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname='jobs_created_by_fk'
  ) THEN
    ALTER TABLE platform.jobs
      ADD CONSTRAINT jobs_created_by_fk
      FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL;
  END IF;
END $$;

INSERT INTO platform.schema_versions(version)
VALUES(4)
ON CONFLICT(version) DO NOTHING;

COMMIT;
