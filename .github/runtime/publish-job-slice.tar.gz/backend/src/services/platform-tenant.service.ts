import { prisma } from "../config/prisma.js";
import { AppError } from "../utils/app-error.js";

const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function uuid(value: string, field: string): string {
  if (!UUID_PATTERN.test(value)) {
    throw new AppError(`${field} is invalid`, 400, "INVALID_IDENTIFIER");
  }
  return value.toLowerCase();
}

export function platformTenancyEnabled(): boolean {
  return process.env.ENABLE_PLATFORM_TENANCY === "true";
}

function migrationError(error: unknown): never {
  const code = typeof error === "object" && error !== null && "code" in error
    ? String((error as { code?: unknown }).code || "")
    : "";
  if (["42P01", "42703", "3F000"].includes(code)) {
    throw new AppError(
      "Platform tenancy migration is not applied",
      503,
      "PLATFORM_MIGRATION_REQUIRED",
    );
  }
  throw error;
}

/**
 * Creates the deterministic personal tenant used to bridge the legacy user-owned
 * website model. SET LOCAL scopes the RLS policy to this one transaction.
 */
export async function ensurePersonalTenant(ownerUserId: string): Promise<string> {
  const tenantId = uuid(ownerUserId, "ownerUserId");
  if (!platformTenancyEnabled()) {
    throw new AppError(
      "Platform tenancy is disabled until the reviewed migration is applied",
      503,
      "PLATFORM_TENANCY_DISABLED",
    );
  }

  try {
    return await prisma.$transaction(async (tx) => {
      await tx.$executeRawUnsafe(
        "SELECT set_config('app.tenant_id', $1, true)",
        tenantId,
      );
      const users = await tx.$queryRawUnsafe<Array<{ name: string }>>(
        `SELECT COALESCE(NULLIF(BTRIM("fullName"),''), NULLIF(BTRIM(email),''), 'Personal Workspace') AS name
         FROM users WHERE id=$1::uuid AND status='ACTIVE' LIMIT 1`,
        tenantId,
      );
      if (!users[0]) {
        throw new AppError("Website owner is unavailable", 409, "OWNER_UNAVAILABLE");
      }

      await tx.$executeRawUnsafe(
        `INSERT INTO platform.tenants(id,name,status,home_cell)
         VALUES($1::uuid,$2,'ACTIVE','local-1')
         ON CONFLICT(id) DO NOTHING`,
        tenantId,
        users[0].name,
      );
      await tx.$executeRawUnsafe(
        `INSERT INTO platform.memberships(tenant_id,user_id,role,status)
         VALUES($1::uuid,$1::uuid,'OWNER','ACTIVE')
         ON CONFLICT(tenant_id,user_id) DO UPDATE
         SET role='OWNER',status='ACTIVE',version=platform.memberships.version+1`,
        tenantId,
      );
      return tenantId;
    });
  } catch (error) {
    if (error instanceof AppError) throw error;
    return migrationError(error);
  }
}

/** Assigns only an unassigned legacy website and never moves a future workspace-owned site. */
export async function assignPersonalTenantToWebsite(
  websiteIdInput: string,
  ownerUserIdInput: string,
): Promise<string> {
  const websiteId = uuid(websiteIdInput, "websiteId");
  const ownerUserId = uuid(ownerUserIdInput, "ownerUserId");
  const tenantId = await ensurePersonalTenant(ownerUserId);

  try {
    const rows = await prisma.$queryRawUnsafe<Array<{ tenantId: string }>>(
      `UPDATE websites
       SET "tenantId"=COALESCE("tenantId",$2::uuid),"updatedAt"=NOW()
       WHERE id=$1::uuid AND "userId"=$2::uuid
       RETURNING "tenantId"`,
      websiteId,
      ownerUserId,
    );
    const assigned = rows[0]?.tenantId;
    if (!assigned) throw new AppError("Website not found", 404, "WEBSITE_NOT_FOUND");
    return uuid(assigned, "tenantId");
  } catch (error) {
    if (error instanceof AppError) throw error;
    return migrationError(error);
  }
}
